from hcs.__main__ import selfcheck
from hcs.const import __version__